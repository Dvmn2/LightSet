package net.dvmn2.lightSet;

import io.papermc.paper.command.brigadier.Commands;
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Главный класс плагина LightSet: динамические прожекторы и освещение
 * на основе световых блоков (minecraft:light).
 */
public final class LightSet extends JavaPlugin {

    private LightManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        LightSettings settings = new LightSettings(this);
        Lang.setLanguage(getConfig().getString("language", "auto"));

        LightStore store = new LightStore(this);
        manager = new LightManager(this, settings, store);
        manager.start();

        getServer().getPluginManager().registerEvents(new LightListener(manager), this);

        LightSetCommand command = new LightSetCommand(manager);
        getLifecycleManager().registerEventHandler(LifecycleEvents.COMMANDS, event -> {
            Commands commands = event.registrar();
            commands.register(command.create(), "Управление источниками света LightSet");
        });

        getLogger().info("LightSet enabled!");
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.shutdown();
        }
        getLogger().info("LightSet disabled!");
    }
}
